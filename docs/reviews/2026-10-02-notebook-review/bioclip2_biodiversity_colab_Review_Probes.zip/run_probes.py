"""Probes for the Framework v1 review of tutorials/bioclip2_biodiversity_colab.ipynb (prefix BIO).

Run from a scratch working directory that holds weights/bioclip-2/{README.md,open_clip_config.json,
open_clip_model.safetensors} (the real, digest-verified snapshot; the safetensors may be a read-only
hard link). The notebook writes its own manifest there. Usage:

    DIMER_NOTEBOOK_CI_PREINSTALLED=1 python run_probes.py <path-to-notebook> [results.json]

Every notebook cell is executed verbatim from the notebook JSON in one namespace. The only changes are
form-field literal substitutions (as an executor sets fields) and a fake `google.colab.files.upload`
for BYOD. Direct API probes (prompt swaps, learning-rate comparison) are labelled as such. CPU only.
Results are appended to results.json after every probe (write-immediately).
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import re
import shutil
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB_PATH = Path(sys.argv[1])
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "results.json")
RESULTS: dict = json.loads(OUT.read_text(encoding="utf-8")) if OUT.is_file() else {"notebook": str(NB_PATH), "probes": {}}
PHASES = os.environ.get("PROBES", "P2,P3,P4,P5,P6").split(",")


def save() -> None:
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def record(name: str, value) -> None:
    RESULTS["probes"][name] = value
    save()
    print(f"### {name}: {json.dumps(value, default=str)[:600]}", flush=True)


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
CODE = [(i, "".join(c["source"])) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
CELL = dict(CODE)
RESULTS["n_cells"] = len(nb["cells"])
RESULTS["code_cells"] = [i for i, _ in CODE]

# ---- fake google.colab -------------------------------------------------------------------------
UPLOAD: dict = {}
google = types.ModuleType("google")
colab = types.ModuleType("google.colab")
files_mod = types.ModuleType("google.colab.files")
files_mod.upload = lambda: dict(UPLOAD)
colab.files = files_mod
google.colab = colab
sys.modules.update({"google": google, "google.colab": colab, "google.colab.files": files_mod})

NS: dict = {"__name__": "__main__"}


def substitute(src: str, fields: dict) -> str:
    for name, literal in fields.items():
        pat = re.compile(rf"^{name} = .*$", re.M)
        if not pat.search(src):
            raise KeyError(f"form field {name} not found")  # EXE6: fail on a missing field
        src = pat.sub(f"{name} = {literal}", src, count=1)
    return src


def run_cell(idx: int, fields: dict | None = None) -> dict:
    src = substitute(CELL[idx], fields or {})
    buf = io.StringIO()
    t0 = time.perf_counter()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src, f"<cell {idx}>", "exec"), NS)
        status, err = "ok", None
    except BaseException as exc:  # noqa: BLE001 - record any failure verbatim
        status, err = "error", f"{type(exc).__name__}: {exc}"
        traceback.print_exc(limit=2, file=buf)
    return {"cell": idx, "status": status, "error": err, "seconds": round(time.perf_counter() - t0, 2),
            "stdout_tail": buf.getvalue()[-1500:]}


def run_cells(indices, fields_by_cell=None, stop_on_error=True) -> list[dict]:
    out = []
    for idx in indices:
        r = run_cell(idx, (fields_by_cell or {}).get(idx))
        out.append(r)
        if r["status"] != "ok" and stop_on_error:
            break
    return out


def summary(runs: list[dict]) -> dict:
    return {"cells_run": [r["cell"] for r in runs], "ok": sum(r["status"] == "ok" for r in runs),
            "first_error": next(({"cell": r["cell"], "error": r["error"]} for r in runs if r["status"] != "ok"), None),
            "seconds": round(sum(r["seconds"] for r in runs), 1)}


# ---- P0 static ---------------------------------------------------------------------------------
compiled = []
for i, s in CODE:
    try:
        compile(s, f"<cell {i}>", "exec")
        compiled.append(True)
    except SyntaxError:
        compiled.append(False)
record("P0_static", {"code_cells": len(CODE), "compile_ok": sum(compiled),
                     "outputs_persisted": sum(bool(c.get("outputs")) for c in nb["cells"] if c["cell_type"] == "code"),
                     "metadata_dimer": nb["metadata"].get("dimer", {}),
                     "infrastructure_labelled_cells": sum("Infrastructure" in "".join(c["source"]) for c in nb["cells"]),
                     "cellView_form": sum(c.get("metadata", {}).get("cellView") == "form" for c in nb["cells"]),
                     "guided_markers": {k: sum(k.lower() in "".join(c["source"]).lower() for c in nb["cells"] if c["cell_type"] == "markdown")
                                        for k in ("How to use", "Roadmap", "Glossary", "Predict", "What to notice", "Check your", "Troubleshoot", "Expected result", "Input →", "conclusion")}})

# ---- P1 default path ---------------------------------------------------------------------------
os.environ.setdefault("DIMER_NOTEBOOK_CI_PREINSTALLED", "1")
default_order = [i for i, _ in CODE]
runs = run_cells(default_order)
P = NS
p1 = summary(runs)
if p1["first_error"] is None:
    zs, tm, vm = P["baseline_zero_shot"], P["test_metrics"], P["val_metrics"]
    p1.update({
        "runtime": {"python": sys.version.split()[0], "torch": P["torch"].__version__, "open_clip": P["open_clip"].__version__, "device": P["pipe"].device},
        "fetched": P["fetched"], "splits": [len(P["train_records"]), len(P["val_records"]), len(P["test_records"])],
        "dataset_digest": P["dataset_manifest"]["digest"],
        "zero_shot_test": {k: zs[k] for k in ("n", "accuracy", "macro_f1", "auroc")},
        "majority": {k: P["baseline_majority"][k] for k in ("accuracy", "macro_f1")},
        "color": {k: P["baseline_color"][k] for k in ("accuracy", "macro_f1")},
        "adapt": {k: P["adapt_result"][k] for k in ("trainable_parameters", "total_parameters", "head_initialisation")},
        "history": P["adapt_result"]["history"],
        "val": {k: vm[k] for k in ("n", "accuracy", "macro_f1", "auroc")},
        "test": {k: tm[k] for k in ("n", "accuracy", "macro_f1", "auroc")},
        "delta_vs_zero_shot": P["evaluation_report"]["delta_vs_zero_shot"],
        "reload_max_abs_score_diff": P["max_score_diff"],
        "outputs": sorted(str(p) for p in Path("outputs").rglob("*") if p.is_file() and "images" not in p.parts),
        "cell_stdout": {r["cell"]: r["stdout_tail"][-700:] for r in runs if r["cell"] in (21, 25, 29)},
    })
record("P1_default_path", p1)


# ---- P2 head displacement (default adapt) --------------------------------------------------------
def head_probe(pipe, class_prompts, classes, test_records, template="a photo of {}."):
    import torch
    init = torch.tensor(pipe._text_embedder([template.format(class_prompts[c]) for c in classes])) * pipe.logit_scale
    w = pipe.classifier_model.head.weight.detach().cpu()
    b = pipe.classifier_model.head.bias.detach().cpu()
    zs = pipe.zero_shot([r["image_bytes"] for r in test_records], {c: class_prompts[c] for c in classes})["predictions"]
    ad = pipe.classify([r["image_bytes"] for r in test_records])["predictions"]
    return {"rel_weight_displacement": float((w - init).norm() / init.norm()),
            "max_abs_weight_change": float((w - init).abs().max()),
            "mean_abs_init_weight": float(init.abs().mean()),
            "max_abs_bias": float(b.abs().max()),
            "argmax_agreement_with_zero_shot": sum(a["label"] == z["label"] for a, z in zip(ad, zs)) / len(ad),
            "max_abs_score_diff_vs_zero_shot": max(abs(a["scores"][c] - z["scores"][c]) for a, z in zip(ad, zs) for c in classes)}


if p1["first_error"] is None and "P2" in PHASES:
    record("P2_head_displacement_default", head_probe(P["pipe"], P["class_prompts"], P["CLASSES"], P["test_records"]))


# ---- P3 direct API: can the default head-only adaptation move when zero-shot is wrong? ------------
def adapt_probe(label, prompts, lr, epochs=4):
    pipe = P["pipe"]
    t0 = time.perf_counter()
    zs = pipe.zero_shot_evaluate(P["test_records"], prompts)
    res = pipe.adapt(P["train_records"], P["val_records"], classes=P["CLASSES"], class_prompts=prompts,
                     epochs=epochs, learning_rate=lr, batch_size=8, trainable_blocks=0, seed=42)
    tm = pipe.evaluate(P["test_records"])
    hp = head_probe(pipe, prompts, P["CLASSES"], P["test_records"])
    return {"case": label, "learning_rate": lr, "epochs": epochs, "zero_shot_test_acc": zs["accuracy"],
            "val_acc_by_epoch": [h.get("val_accuracy") for h in res["history"]],
            "train_loss_by_epoch": [h.get("train_loss") for h in res["history"]],
            "adapted_test_acc": tm["accuracy"], "adapted_test_macro_f1": tm["macro_f1"],
            "rel_weight_displacement": hp["rel_weight_displacement"], "seconds": round(time.perf_counter() - t0, 1)}


if p1["first_error"] is None and "P3" in PHASES:
    C = P["CLASSES"]
    sp = P["SAMPLE_CLASS_PROMPTS"]
    swapped = {C[i]: sp[C[(i + 1) % len(C)]] for i in range(len(C))}  # each class gets another species' name
    neutral = {c: f"species {k + 1}" for k, c in enumerate(C)}
    p3 = []
    try:
        for label, prompts in (("swapped scientific names", swapped), ("neutral names 'species k'", neutral)):
            for lr in (1e-4, 1e-2):
                p3.append(adapt_probe(label, prompts, lr))
                record("P3_adaptation_when_zero_shot_is_wrong", {"note": "direct API calls with the notebook's split, epochs=4, batch 8, head-only, seed 42; only class_prompts and learning_rate differ", "runs": p3})
    except Exception as exc:  # noqa: BLE001
        record("P3_adaptation_when_zero_shot_is_wrong", {"runs": p3, "error": f"{type(exc).__name__}: {exc}"})

# ---- P4 active learning: TRAINABLE_BLOCKS = 1 rerun from Section 9 -----------------------------------
if p1["first_error"] is None and "P4" in PHASES:
    runs = run_cells([25, 27, 29, 31], {25: {"TRAINABLE_BLOCKS": "1  # @param {type:\"integer\"}"}})
    p4 = summary(runs)
    if p4["first_error"] is None:
        p4.update({"trainable_parameters": P["adapt_result"]["trainable_parameters"],
                   "history": P["adapt_result"]["history"],
                   "test": {k: P["test_metrics"][k] for k in ("accuracy", "macro_f1", "auroc")},
                   "reload_max_abs_score_diff": P["max_score_diff"],
                   "artifact_tensors": len(P["artifact_manifest"]["tensors"]),
                   "artifact_bytes": P["artifact_manifest"]["files"][0]["bytes"],
                   "zero_shot_unchanged_after": P["pipe"].zero_shot_evaluate(P["test_records"], P["class_prompts"])["accuracy"]})
    record("P4_trainable_blocks_1_rerun", p4)
    run_cells([25])  # restore the default head


# ---- P5 BYOD ------------------------------------------------------------------------------------
from PIL import Image  # noqa: E402

SAMPLE = P["generate_sample_dataset"]()
BY_CLASS: dict = {}
for r in SAMPLE:
    BY_CLASS.setdefault(r["label"], []).append(r)


def make_zip(entries: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in entries.items():
            zf.writestr(name, data)
    return buf.getvalue()


def per_class(n, classes=None, prefix="", name=lambda r, k: r["file"]):
    out = {}
    for c in classes or sorted(BY_CLASS):
        for k, r in enumerate(BY_CLASS[c][:n]):
            out[f"{prefix}{c}/{name(r, k)}"] = r["image_bytes"]
    return out


def byod(label, zip_bytes, cells, prompts="dict(SAMPLE_CLASS_PROMPTS)", clear=True, file_name="mydata.zip"):
    if clear and Path("work/byod").exists():
        shutil.rmtree("work/byod")
    UPLOAD.clear()
    if zip_bytes is not None:
        UPLOAD[file_name] = zip_bytes
    fields = {15: {"USE_BYOD": "True", "BYOD_CLASS_PROMPTS": prompts}}
    runs = run_cells(cells, fields)
    s = summary(runs)
    s["case"] = label
    if runs and runs[0]["status"] == "ok":
        s["n_records"] = len(P["records"])
        s["splits"] = [len(P["train_records"]), len(P["val_records"]), len(P["test_records"])]
    return s, runs


if "P5" in PHASES:
    B = {}
    full = [15, 17, 19, 21, 23, 25, 27, 29, 31]
    s, runs = byod("positive: 4 classes x 7 <label>/<image> folders", make_zip(per_class(7)), full)
    if s["first_error"] is None:
        s["test"] = {k: P["test_metrics"][k] for k in ("n", "accuracy", "macro_f1")}
        s["reload_max_abs_score_diff"] = P["max_score_diff"]
        s["result_data_source"] = json.loads(Path("outputs/bioclip2_biodiversity_result.json").read_text(encoding="utf-8"))["data_source"]
    B["B1_positive"] = s
    record("P5_byod", B)

    B["B2a_stated_minimum_4x3"] = byod("4 classes x 3 (12 records: meets 'at least 8 records and 3 per class')", make_zip(per_class(3)), full)[0]
    record("P5_byod", B)
    B["B2b_2x6"] = byod("2 classes x 6 (12 records)", make_zip(per_class(6, ["chipping_sparrow", "song_sparrow"])), full)[0]
    record("P5_byod", B)
    B["B2c_2x7"] = byod("2 classes x 7 (14 records)", make_zip(per_class(7, ["chipping_sparrow", "song_sparrow"])), [15, 25])[0]
    record("P5_byod", B)
    B["B3_enclosing_folder"] = byod("zip with one enclosing folder mydata/<label>/<image>", make_zip(per_class(7, prefix="mydata/")), [15])[0]
    record("P5_byod", B)

    # MPO: a JPEG-family multi-picture file, as some cameras write; Pillow reports format 'MPO'
    entries = per_class(7)
    im = Image.open(io.BytesIO(next(iter(entries.values()))))
    mbuf = io.BytesIO()
    try:
        im.save(mbuf, "MPO", save_all=True, append_images=[im.copy()])
        mpo = mbuf.getvalue()
        first = next(iter(entries))
        entries[first] = mpo
        s = byod("one MPO-format .jpg among 28", make_zip(entries), [15])[0]
        s["pillow_format_of_probe_file"] = Image.open(io.BytesIO(mpo)).format
        B["B4_mpo"] = s
    except Exception as exc:  # noqa: BLE001
        B["B4_mpo"] = {"error": f"could not build MPO: {exc}"}
    record("P5_byod", B)

    entries = per_class(7)
    entries["../byod_evil/escaped.txt"] = b"written outside the upload directory"
    if Path("work/byod_evil").exists():
        shutil.rmtree("work/byod_evil")
    s = byod("zip member '../byod_evil/escaped.txt' (sibling-prefix traversal)", make_zip(entries), [15])[0]
    s["escaped_file_exists"] = Path("work/byod_evil/escaped.txt").is_file()
    s["escaped_path"] = str(Path("work/byod_evil/escaped.txt").resolve())
    B["B5_traversal_prefix"] = s
    record("P5_byod", B)

    # Camera-style filenames repeated across label folders
    s = byod("same file names (IMG_0001.jpg..) in every label folder", make_zip(per_class(7, name=lambda r, k: f"IMG_{k + 1:04d}.jpg")), [15])[0]
    if s["first_error"] is None:
        imgs = sorted(Path("outputs/images").glob("IMG_*.jpg"))
        s["outputs_images_IMG_files"] = len(imgs)
        try:
            P["load_byod_dataset"]("outputs/bioclip2_biodiversity_sample_dataset.csv")
            s["template_csv_reloads"] = True
        except Exception as exc:  # noqa: BLE001
            s["template_csv_reloads"] = f"{type(exc).__name__}: {str(exc)[:200]}"
    B["B6_filename_collision"] = s
    record("P5_byod", B)

    # Second upload without a restart: does the first upload's data persist?
    byod("upload A", make_zip(per_class(7, ["chipping_sparrow", "dark_eyed_junco"])), [15])
    s = byod("upload B after A, same session", make_zip(per_class(7, ["song_sparrow", "white_throated_sparrow"])), [15], clear=False)[0]
    s["classes_seen"] = P["CLASSES"] if s["first_error"] is None else None
    B["B7_second_upload_merges"] = s
    record("P5_byod", B)

    B["B8_empty_prompts"] = byod("USE_BYOD with BYOD_CLASS_PROMPTS = {}", make_zip(per_class(7)), [15], prompts="{}")[0]
    record("P5_byod", B)
    B["B9_cancelled_upload"] = byod("upload dialog returns nothing", None, [15])[0]
    record("P5_byod", B)

    csvzip = {"data/images/" + k.replace("/", "_"): v for k, v in per_class(7).items()}
    csvzip["data/labels.csv"] = ("id,image,label\n" + "".join(f"{k.split('/')[0]}_{i},images/{k.replace('/', '_')},{k.split('/')[0]}\n" for i, k in enumerate(per_class(7)))).encode()
    B["B10_csv_positive"] = byod("zip holding data/labels.csv + images", make_zip(csvzip), [15])[0]
    record("P5_byod", B)


# ---- P6 BYOD through the CSV-in-zip layout (the folder layout fails, see P5) ----------------------
def csv_zip(n, classes=None, root="data", name=lambda r, k: r["file"], table="labels.csv", mutate=None):
    entries, rows = {}, ["id,image,label"]
    for c in classes or sorted(BY_CLASS):
        for k, r in enumerate(BY_CLASS[c][:n]):
            rel = f"{c}/{name(r, k)}"
            data = r["image_bytes"]
            if mutate is not None:
                data = mutate(c, k, data)
            entries[f"{root}/{rel}"] = data
            rows.append(f"{c}-{k},{rel},{c}")
    entries[f"{root}/{table}"] = (chr(10).join(rows) + chr(10)).encode()
    return make_zip(entries)


if "P6" in PHASES:
    C6 = {}
    full = [15, 17, 19, 21, 23, 25, 27, 29, 31]
    s = byod("CSV layout positive: 4 classes x 7", csv_zip(7), full)
    s = s[0]
    if s["first_error"] is None:
        s["test"] = {k: P["test_metrics"][k] for k in ("n", "accuracy", "macro_f1")}
        s["reload_max_abs_score_diff"] = P["max_score_diff"]
        s["result_data_source"] = json.loads(Path("outputs/bioclip2_biodiversity_result.json").read_text(encoding="utf-8"))["data_source"]
        s["sample_named_csv_holds_byod"] = Path("outputs/bioclip2_biodiversity_sample_dataset.csv").read_text(encoding="utf-8").count(chr(10)) - 1
    C6["C1_csv_positive_full_path"] = s
    record("P6_byod_csv", C6)
    C6["C2_stated_minimum_4x3"] = byod("CSV 4 classes x 3 (meets 'at least 8 records and 3 per class')", csv_zip(3), full)[0]
    record("P6_byod_csv", C6)
    C6["C3_2x6"] = byod("CSV 2 classes x 6", csv_zip(6, ["chipping_sparrow", "song_sparrow"]), full)[0]
    record("P6_byod_csv", C6)
    C6["C4_2x7"] = byod("CSV 2 classes x 7", csv_zip(7, ["chipping_sparrow", "song_sparrow"]), [15, 25])[0]
    record("P6_byod_csv", C6)
    C6["C4b_4x5"] = byod("CSV 4 classes x 5", csv_zip(5), [15, 25])[0]
    C6["C4c_4x4"] = byod("CSV 4 classes x 4", csv_zip(4), [15, 25])[0]
    record("P6_byod_csv", C6)

    def to_mpo(c, k, data):
        if c == "chipping_sparrow" and k == 0:
            im = Image.open(io.BytesIO(data))
            b = io.BytesIO()
            im.save(b, "MPO", save_all=True, append_images=[im.copy()])
            return b.getvalue()
        return data

    C6["C5_mpo"] = byod("CSV, one MPO-format .jpg among 28", csv_zip(7, mutate=to_mpo), [15])[0]
    record("P6_byod_csv", C6)
    s = byod("CSV, camera file names IMG_000k.jpg repeated in every label folder", csv_zip(7, name=lambda r, k: f"IMG_{k + 1:04d}.jpg"), [15])[0]
    if s["first_error"] is None:
        s["outputs_images_IMG_files"] = len(sorted(Path("outputs/images").glob("IMG_*.jpg")))
        try:
            P["load_byod_dataset"]("outputs/bioclip2_biodiversity_sample_dataset.csv")
            s["template_csv_reloads"] = True
        except Exception as exc:  # noqa: BLE001
            s["template_csv_reloads"] = f"{type(exc).__name__}: {str(exc)[:200]}"
    C6["C6_filename_collision"] = s
    record("P6_byod_csv", C6)
    byod("upload A", csv_zip(7, ["chipping_sparrow", "dark_eyed_junco"], root="a"), [15], file_name="a.zip")
    s = byod("upload B (b/labels.csv) after A (a/labels.csv), same session", csv_zip(7, ["song_sparrow", "white_throated_sparrow"], root="b"), [15], clear=False, file_name="b.zip")[0]
    s["classes_used"] = P["CLASSES"] if s["first_error"] is None else None
    s["data_source_printed"] = P.get("data_source")
    C6["C7_second_upload"] = s
    record("P6_byod_csv", C6)
    C6["C8_empty_prompts"] = byod("CSV with BYOD_CLASS_PROMPTS = {}", csv_zip(7), [15], prompts="{}")[0]
    record("P6_byod_csv", C6)

RESULTS["finished"] = True
save()
print("done")
